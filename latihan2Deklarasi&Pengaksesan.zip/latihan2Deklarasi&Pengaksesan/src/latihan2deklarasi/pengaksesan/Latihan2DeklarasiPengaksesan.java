/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan2deklarasi.pengaksesan;

/**
 *
 * @author FirmanArdhiansyah IF-2 10117956
 */
public class Latihan2DeklarasiPengaksesan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
        //Deklarasi Variabel
        int nilaiInt;
        final double PHI = 3.14; //konstanta uppercase
        boolean nilaiLogika;
        char nilaiKarakter;
        
        //Memberi nilai ke variablel
        nilaiInt      = 78;
        nilaiLogika   = false;
        nilaiKarakter ='D';
        
        //Menampilkan hasil
        System.out.println();
        System.out.println("Isi Variabel nilai = " + nilaiInt);
        System.out.println("Variabel PHI =" + PHI);
        System.out.println("Isi Variabel logika ="   + nilaiLogika);
        System.out.println("Isi Variabel karakter =" + nilaiKarakter);
        
    }
    
}
